const ADMIN_PASSWORD = "admin=Dilshodbek"; // O'zgartiring

document.getElementById('login-button').addEventListener('click', () => {
    const password = document.getElementById('password').value;

    if (password === ADMIN_PASSWORD) {
        document.getElementById('login-form').style.display = 'none';
        document.getElementById('admin-panel').style.display = 'block';
        loadUsers();
    } else {
        document.getElementById('error-message').textContent = "Parol noto'g'ri. Iltimos, qayta urinib ko'ring.";
    }
});

function loadUsers() {
    const users = [];
    let totalCoins = 0;

    for (let i = 0; i < localStorage.length; i++) {
        const username = localStorage.key(i);
        const userData = JSON.parse(localStorage.getItem(username));
        if (userData) {
            users.push(userData);
            totalCoins += userData.balance;
        }
    }

    const userList = document.getElementById('user-list');
    userList.innerHTML = ''; // Mavjud foydalanuvchilar ro'yxatini tozalash
    users.forEach(user => {
        const userDiv = document.createElement('div');
        userDiv.classList.add('user');
        userDiv.innerHTML = `
            <strong>${user.username}</strong> - Balans: ${user.balance} ppg
            <button onclick="removeUser('${user.username}')">O'chirish</button>
        `;
        userList.appendChild(userDiv);
    });

    document.getElementById('total-users').textContent = users.length;
    document.getElementById('total-coins').textContent = totalCoins;
}

function removeUser(username) {
    localStorage.removeItem(username);
    loadUsers();
}

document.getElementById('add-user-button').addEventListener('click', () => {
    const username = document.getElementById('new-username').value;
    const balance = parseFloat(document.getElementById('new-balance').value);

    if (username && !isNaN(balance)) {
        localStorage.setItem(username, JSON.stringify({ username, balance }));
        loadUsers();
        document.getElementById('new-username').value = '';
        document.getElementById('new-balance').value = '';
    } else {
        alert("Iltimos, to'g'ri foydalanuvchi ismini va balansni kiriting.");
    }
});

document.getElementById('edit-user-button').addEventListener('click', () => {
    const username = document.getElementById('edit-username').value;
    const newBalance = parseFloat(document.getElementById('edit-balance').value);

    if (username && !isNaN(newBalance)) {
        const userData = JSON.parse(localStorage.getItem(username));
        if (userData) {
            userData.balance = newBalance;
            localStorage.setItem(username, JSON.stringify(userData));
            loadUsers();
            document.getElementById('edit-username').value = '';
            document.getElementById('edit-balance').value = '';
        } else {
            alert("Foydalanuvchi topilmadi.");
        }
    } else {
        alert("Iltimos, to'g'ri foydalanuvchi ismini va balansni kiriting.");
    }
});

document.getElementById('search-button').addEventListener('click', () => {
    const username = document.getElementById('search-username').value;
    const userData = JSON.parse(localStorage.getItem(username));

    if (userData) {
        alert(`Foydalanuvchi: ${userData.username}\nBalans: ${userData.balance} ppg`);
    } else {
        alert("Foydalanuvchi topilmadi.");
    }
});
