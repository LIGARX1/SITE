let balance = 0;
const balanceDisplay = document.getElementById('balance');
const referralButton = document.getElementById('referral-button');
const youtubeButton = document.getElementById('youtube-button');
const copyNotification = document.getElementById('copy-notification');
const coin = document.getElementById('coin');

// Foydalanuvchini tekshirish
function checkUser() {
    const storedUsername = localStorage.getItem('currentUser');
    if (storedUsername) {
        const userData = JSON.parse(localStorage.getItem(storedUsername));
        balance = userData.balance;
        balanceDisplay.textContent = balance;
    }
}

// Tanga bosilganda balansni oshirish
coin.addEventListener('click', () => {
    balance += 1;
    balanceDisplay.textContent = balance;
    const currentUser = localStorage.getItem('currentUser');
    const userData = JSON.parse(localStorage.getItem(currentUser));
    userData.balance = balance;
    localStorage.setItem(currentUser, JSON.stringify(userData));
});

// Referral linkni nusxalash
referralButton.addEventListener('click', () => {
    const currentUser = localStorage.getItem('currentUser');
    const referralLink = `${window.location.href}?ref=${currentUser}`;
    navigator.clipboard.writeText(referralLink).then(() => {
        copyNotification.textContent = "LINK COPYI!";
        copyNotification.style.display = 'block';
        setTimeout(() => {
            copyNotification.style.display = 'none';
        }, 2000);
    });
});

// YouTube tugmasi
youtubeButton.addEventListener('click', () => {
    const youtubeLink = 'https://www.youtube.com/@PPG_TOKEN';
    window.open(youtubeLink, '_blank');
});

// Foydalanuvchini tekshirish
checkUser();
